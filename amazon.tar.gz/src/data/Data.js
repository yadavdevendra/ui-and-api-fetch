export const token = `eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1c2VyX2lkIjoiNjMzMjlkN2YwNDUxYzA3NGFhMGUxNWE4Iiwicm9sZSI6ImN1c3RvbWVyIiwiZXhwIjoxNjk4NzMxOTc2LCJpc3MiOiJodHRwczpcL1wvYXBwcy5jZWRjb21tZXJjZS5jb20iLCJ0b2tlbl9pZCI6IjYzNWY2NDQ4YzQxY2M2MjdhMzBjNmIyMiJ9.o0XvqNpmiAaXQgWC8LgaBrhx6Kjc6rwm0vi-aG-ezZHp3Ph1jcaBqKQq1u9PQSwiCjU6US8xiqMbN_l5JYEwmPOWWQF43Fdt8V2i_dYp2L4mj51rKn9pH7xCloNPAiqCAp7IlfdwXU2NL5cYlb8p4Ve9axRKuPaZ6FpEL49fP8zjlT5gsfR7lr5UD_iKmBH-F-R4ORgQC3vR0CfsW42XXebfTiKf5fh2qBAIrjtSPJyO0jgNxLCTppnT3ruBf3yDL7EcAOFXzUZn_G8NsOSaZp5AvMWIMDkpmBO0VvgkIqSuYOlICki6riprysfwhuwU1XAtpNwI6N571dfUTPhXsw`;
export const payload={
    "0": {
        "category_settings": {
            "barcode_exemption": false,
            "browser_node_id": "0",
            "primary_category": "default",
            "sub_category": "default",
            "mutated": {}
        },
        "dont_validate_barcode": true,
        "parent_listing_type": "offer_listing",
        "status": "Inactive",
        "source_product_id": "42298885865686",
        "container_id": "7516581658838",
        "shop_id": "640",
        "target_marketplace": "amazon",
        "type": "simple",
        "isVariant": true,
        "source_shop_id": "381"
    },
    "1": {
        "title": "Classic Mallory Loomstate Linen eee",
        "sku": "75165816588380",
        "unset": {
            "description": 1,
            "main_image": 1,
            "additional_images": 1,
            "inventory_fulfillment_latency": 1,
            "edited_variant_attributes": 1
        },
        "category_settings": {
            "barcode_exemption": false,
            "browser_node_id": "0",
            "primary_category": "default",
            "sub_category": "default",
            "attributes_mapping": {
                "required_attribute": [
                    {
                        "amazon_attribute": "condition-type (condition-type)",
                        "custom_text": "",
                        "recommendation": "CollectibleLikeNew",
                        "shopify_attribute": "",
                        "shopify_select": "recommendation"
                    }
                ],
                "optional_attribute": []
            },
        },
        "target_marketplace": "amazon",
        "container_id": "7516581658838",
        "shop_id": "640",
        "source_product_id": "7516581658838",
        "source_shop_id": "381",
        "dont_validate_barcode": true,
        "parent_listing_type": "offer_listing"
    },
    "target_marketplace": "eyJtYXJrZXRwbGFjZSI6ImFsbCIsInNob3BfaWQiOm51bGx9"
  }