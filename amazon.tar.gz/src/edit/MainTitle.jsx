import {
    Page,
    Layout,
    Card,
    TextContainer,
    Text,
    TextField,
    ChoiceList,
} from "@shopify/polaris";
import React, { useEffect } from "react";
import { useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import {token} from '../data/Data'
import Titleofedit from "./Titleofedit";

function MainTitle({ labeldata, childlabel, valuedata, childvalue, textdata, subtext}) {
 
    const id = useParams([]);
    var result = Object.keys(id).map((key) => [id[key]]);
    //   const handleChoiceListChange = useCallback((value) => setSelected(value), []);
    function handleChoiceListChange(value) {
        setSelected(value);
        console.log("selected", selected);
    }
    //   const handleTextFieldChange = useCallback((value) => setTextFieldValue(value),[]);
    function handleTextFieldChange(value) {
        setTextFieldValue(value);
        console.log("textFieldValue", textFieldValue);
    }



    return (
        <>
        </>
    );
}
export default MainTitle;